package com.everis.rest;



import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.everis.rest.models.repository.IStudentRepository;
import com.everis.rest.models.services.StudentServiceImpl;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class ProyectApplicationTests {

	@InjectMocks
	StudentServiceImpl studenService;
	
	@Mock
	IStudentRepository repository;
	
	private static final long id=1;
	
	@Test
	public void findTest() {
		
		studenService.findById(id);
		verify(repository).findById(id);
		
		//https://www.youtube.com/watch?v=jPuEALkZTBo
	}
	
	

}
