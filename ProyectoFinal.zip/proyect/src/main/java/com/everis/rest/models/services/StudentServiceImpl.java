package com.everis.rest.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.everis.rest.models.entity.Student;
import com.everis.rest.models.repository.IStudentRepository;

@Service
public class StudentServiceImpl implements IStudentService{

	@Autowired
	private IStudentRepository studentRepository;
	
	@Override  
	@Transactional(readOnly = true)
	public List<Student> findAll() {
		
		return studentRepository.findAll();
	}

	@Override
	@Transactional
	public Student save(Student student) {
		
		return studentRepository.save(student);
	}

	@Override
	@Transactional
	public void delete(Long id) {

       studentRepository.deleteById(id);
     	
	}
	
	@Override
	@Transactional(readOnly = true)
	public Student findById(Long id) {
		// TODO Auto-generated method stub
		return studentRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional(readOnly = true)
	public Student findStudentByID(Long id) {
		// TODO Auto-generated method stub
		return studentRepository.findByIdSQL(id);
	}

}
