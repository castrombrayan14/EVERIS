package com.everis.rest.models.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

//cliente
@Entity
public class Familie implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull(message = "Ingresar Datos")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long family_id;
	//se ingresa en postman el atributo de la clase
	@NotNull(message = "Ingresar Datos")
	private String family_name;
	@Column(name="parent_id")
	// parentID el atributo de la clase en postman se ingresa
	private Long parentId;
	
	@OneToMany(cascade = CascadeType.ALL )	
	@JoinColumn(name="family_id" , referencedColumnName = "family_id")
	private List<FamilyMembers> familyMember= new ArrayList<>();

	public Familie() {
		
	}
	
	public Long getFamily_id() {
		return family_id;
	}

	public void setFamily_id(Long family_id) {
		this.family_id = family_id;
	}

	public String getFamily_name() {
		return family_name;
	}

	public void setFamily_name(String family_name) {
		this.family_name = family_name;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public List<FamilyMembers> getFamilyMember() {
		return familyMember;
	}

	public void setFamilyMember(List<FamilyMembers> familyMember) {
		this.familyMember = familyMember;
	}	
	
		
}
