package com.everis.rest.models.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
//lenguaje
@Entity
//nombre de la tabla
@Table(name="Students")
public class Student implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotNull(message = "Ingresar Datos")
	@Column(name="student_id")
	private Long id;
	@NotNull(message = "Ingresar Datos")
	private String gender;
	@NotNull(message = "Ingresar Datos")
	private String first_name;
	@NotNull(message = "Ingresar Datos")
	private String middle_name;
	@NotNull(message = "Ingresar Datos")
	private String last_name;
	@NotNull(message = "Ingresar Datos")
	private String other_student_details;
	
	@Column(name="date_of_birth")
	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date dateOfBirth;
	
	@ManyToMany
	@JoinTable(name="parents_students",joinColumns = @JoinColumn(name="student_id",referencedColumnName = "student_id"),
	inverseJoinColumns = @JoinColumn(name="parent_id",referencedColumnName = "parent_id"))
	private Set<Parent> parents=new HashSet<Parent>();
	
	@OneToMany(cascade = CascadeType.ALL )	
	@JoinColumn(name="student_id" , referencedColumnName = "student_id")
	private List<FamilyMembers> familyMember= new ArrayList<>();
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	
	

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getOther_student_details() {
		return other_student_details;
	}

	public void setOther_student_details(String other_student_details) {
		this.other_student_details = other_student_details;
	}

	
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Set<Parent> getParents() {
		return parents;
	}

	public void setParents(Set<Parent> parents) {
		this.parents = parents;
	}

	public List<FamilyMembers> getFamilyMember() {
		return familyMember;
	}

	public void setFamilyMember(List<FamilyMembers> familyMember) {
		this.familyMember = familyMember;
	}

	
}
