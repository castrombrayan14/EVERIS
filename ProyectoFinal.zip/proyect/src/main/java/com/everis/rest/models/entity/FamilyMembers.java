package com.everis.rest.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FamilyMembers implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="family_member_id")
	private Long id;
	@Column(name="parent_or_student_member")
	public String parentOrStudent;
	
	@Column(name="parent_id")
	// parentID el atributo de la clase en postman se ingresa
	private Long parentId;
	
	@Column(name="student_id")
	// parentID el atributo de la clase en postman se ingresa
	private Long studentId;
	
	@Column(name="family_id")
	// parentID el atributo de la clase en postman se ingresa
	private Long familyId;

	public FamilyMembers() {
	
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getParentOrStudent() {
		return parentOrStudent;
	}

	public void setParentOrStudent(String parentOrStudent) {
		this.parentOrStudent = parentOrStudent;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public Long getFamilyId() {
		return familyId;
	}

	public void setFamilyId(Long familyId) {
		this.familyId = familyId;
	}

    

}
