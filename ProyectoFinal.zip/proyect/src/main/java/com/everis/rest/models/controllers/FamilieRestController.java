package com.everis.rest.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.everis.rest.models.entity.Familie;
import com.everis.rest.models.entity.Parent;
import com.everis.rest.models.services.IFamilieService;

@RestController
@RequestMapping("/api")
public class FamilieRestController {

	@Autowired
	private IFamilieService familieService;
	
	@GetMapping("/listFamilies")
	public ResponseEntity<?> listFamilies(){
		
		List<Familie> listaFamilies = familieService.findAll();
	    if(listaFamilies!=null) {
	    	if(listaFamilies.size()!=0) {
	    		return new ResponseEntity<>(listaFamilies, HttpStatus.OK);
	    	}else {
	    	    return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	    	}
	    } else {
	    	
	    	return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	    }
	
	}
	
	
	//se manda el id de la clase parent para buscar la lista
	@PostMapping("/saveFamilies")
	public void saveFamilie(@RequestBody Familie familie){
		
		familieService.saveFamilie(familie);
		
	}
	
	@PostMapping("/families_parent")
	public ResponseEntity<?> listFamiliesofParent(@RequestBody Parent parent){
		
		List<Familie> listaFamilies= familieService.getFamiliesParent(parent.getId());
		  if(listaFamilies!=null) {
		    	if(listaFamilies.size()!=0) {
		    		return new ResponseEntity<>(listaFamilies, HttpStatus.OK);
		    	}else {
		    	    return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		    	}
		    } else {
		    	
		    	return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		    }
	}
	
}
