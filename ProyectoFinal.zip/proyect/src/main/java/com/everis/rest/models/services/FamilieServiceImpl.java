package com.everis.rest.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.everis.rest.models.entity.Familie;
import com.everis.rest.models.repository.IFamilieRepository;

@Service
public class FamilieServiceImpl implements IFamilieService{
	
	@Autowired
	private IFamilieRepository familieRepository;
	
	

	@Override
	@Transactional(readOnly = true)
	public List<Familie> findAll() {

		

		return familieRepository.findAll();
	}

	@Override
	@Transactional
	public void saveFamilie(Familie familie) {

		familieRepository.save(familie);
         
		
	}

	@Override
	@Transactional(readOnly = true)
	public List<Familie> getFamiliesParent(Long id) {


		return (List<Familie>) familieRepository.findByParentId(id);
	}

}
