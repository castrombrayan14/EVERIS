package com.everis.rest.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.everis.rest.models.entity.FamilyMembers;
import com.everis.rest.models.repository.IFamilyMemberRepository;

@Service
public class FamilyMemberServiceImpl implements IFamilyMemberService{
	
	@Autowired
	private IFamilyMemberRepository familyMemberRepository;
	
	

	@Override
	@Transactional(readOnly = true)
	public List<FamilyMembers> findAll() {

		

		return familyMemberRepository.findAll();
	}

	@Override
	@Transactional
	public void saveFamilyMember(FamilyMembers familyMembers) {

		familyMemberRepository.save(familyMembers);
         
	}

	@Override
	public List<FamilyMembers> getFamilyMemberFamilie(Long familieId) {
		
		return (List<FamilyMembers>) familyMemberRepository.findByFamilyId(familieId);
	}

}
