package com.everis.rest.models.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="Parents")
public class Parent implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotNull(message = "Ingresar Datos")
	@Column(name="parent_id")
	private Long id;
	@NotNull(message = "Ingresar Datos")
	private String gender;
	@NotNull(message = "Ingresar Datos")
	private String first_name;
	@NotNull(message = "Ingresar Datos")
	private String middle_name;
	@NotNull(message = "Ingresar Datos")
	private String last_name;
	@NotNull(message = "Ingresar Datos")
	private String other_parents_details;
	
	//al borrar un pariente automaticamente tambien borrara en familia el registro asociado
	@OneToMany(cascade = CascadeType.ALL )	
	@JoinColumn(name="parent_id" , referencedColumnName = "parent_id")
	private List<Familie> familie= new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL )	
	@JoinColumn(name="parent_id" , referencedColumnName = "parent_id")
	private List<FamilyMembers> familyMember= new ArrayList<>();
	
	
	@ManyToMany
	@JsonBackReference
	@JoinTable(name="parents_students",joinColumns = @JoinColumn(name="parent_id",referencedColumnName = "parent_id"),
	inverseJoinColumns = @JoinColumn(name="student_id",referencedColumnName = "student_id"))
	private Set<Student> students=new HashSet<Student>();
	
	
	public List<Familie> getFamilie() {
		return familie;
	}
	public void setFamilie(List<Familie> familie) {
		this.familie = familie;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getOther_parents_details() {
		return other_parents_details;
	}
	public void setOther_parents_details(String other_parents_details) {
		this.other_parents_details = other_parents_details;
	}
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	
	public void addStudent(Student student) {
		
		this.students.add(student);
	}
	public List<FamilyMembers> getFamilyMember() {
		return familyMember;
	}
	public void setFamilyMember(List<FamilyMembers> familyMember) {
		this.familyMember = familyMember;
	}
	
	
}
