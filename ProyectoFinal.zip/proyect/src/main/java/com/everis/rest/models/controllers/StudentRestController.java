package com.everis.rest.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.everis.rest.models.entity.Student;
import com.everis.rest.models.services.IStudentService;

@RestController
@RequestMapping("/api")
public class StudentRestController {
	
	@Autowired
	private	IStudentService studentService;
	
//para llamar en la url	
	@GetMapping("/listStudents")
	public List<Student> listStudent() {
		
		return studentService.findAll();
	}

	@GetMapping("/students/{id}")
	public Student findStudent(@PathVariable Long id) {
		
		return studentService.findById(id);
		
	}
	@PostMapping("/saveStudents")
	@ResponseStatus(HttpStatus.CREATED)
	public Student saveStudent(@RequestBody Student student) {
		
		return studentService.save(student)	;
	} 

	@PutMapping("/updateStudents/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public Student updateStudent(@RequestBody Student student,@PathVariable Long id) {
		
		Student studentCurrent =studentService.findById(id);
		
		studentCurrent.setGender(student.getGender());
		studentCurrent.setFirst_name(student.getFirst_name());
		studentCurrent.setMiddle_name(student.getMiddle_name());
		studentCurrent.setLast_name(student.getLast_name());
		studentCurrent.setOther_student_details(student.getOther_student_details());
     	studentCurrent.setDateOfBirth(student.getDateOfBirth());
		
		return 	studentService.save(studentCurrent);
		
	}
	
	@DeleteMapping("/deleteStudents/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteStudent(@PathVariable Long id) {
		studentService.delete(id);
		
	}
	
}
