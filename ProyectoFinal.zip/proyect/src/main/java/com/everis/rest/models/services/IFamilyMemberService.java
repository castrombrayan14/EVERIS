package com.everis.rest.models.services;

import java.util.List;

import com.everis.rest.models.entity.FamilyMembers;

public interface IFamilyMemberService {

	public List<FamilyMembers> findAll();
	
	public void saveFamilyMember(FamilyMembers familyMembers);
	
	public List<FamilyMembers> getFamilyMemberFamilie (Long familieId);
}
