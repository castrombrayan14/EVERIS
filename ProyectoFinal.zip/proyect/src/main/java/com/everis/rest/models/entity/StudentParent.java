package com.everis.rest.models.entity;

public class StudentParent {

	private Student student;
	private Parent parent;
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Parent getParent() {
		return parent;
	}
	public void setParent(Parent parent) {
		this.parent = parent;
	}
	public StudentParent() {
	
	}

	
}
