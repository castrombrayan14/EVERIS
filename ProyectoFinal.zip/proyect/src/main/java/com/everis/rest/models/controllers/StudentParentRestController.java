package com.everis.rest.models.controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;   
import org.springframework.web.bind.annotation.RestController;

import com.everis.rest.models.entity.Parent;
import com.everis.rest.models.entity.Student;
import com.everis.rest.models.entity.StudentParent;
import com.everis.rest.models.services.IParentService;
import com.everis.rest.models.services.IStudentService;

@RestController
@RequestMapping("/api")
public class StudentParentRestController {

	@Autowired
	public IStudentService studentService;
	@Autowired
	public IParentService parentService;
	
	@PostMapping("/students_parents")
	public ResponseEntity<?> listaStudentsParent(@RequestBody Parent parent){
		
		Parent parentDb = parentService.findById(parent.getId());
		if(parentDb!=null) {
		Collection<Student> listaStudents = parentDb.getStudents(); 
		if(listaStudents!=null) {
			
			return new ResponseEntity<>(listaStudents,HttpStatus.OK);
		}
		
		}
	    
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/save_students_parents")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> saveStudentParent(@RequestBody StudentParent studentparent) {
		
		Parent parentDb = parentService.findById(studentparent.getParent().getId());
		
		if(parentDb!=null) {
			
			Student studentDb= studentService.findById(studentparent.getStudent().getId());
		
		parentDb.addStudent(studentDb);
		
		parentService.save(parentDb);
		
		  return new ResponseEntity<Void>(HttpStatus.CREATED);
		}
		
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	} 
}
