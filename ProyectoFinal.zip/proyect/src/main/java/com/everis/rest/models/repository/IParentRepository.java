package com.everis.rest.models.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.everis.rest.models.entity.Parent;

@Repository
public interface IParentRepository extends JpaRepository<Parent, Long>{
	
}
