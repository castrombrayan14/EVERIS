package com.everis.rest.models.services;

import java.util.List;

import com.everis.rest.models.entity.Student;

public interface IStudentService {
	
	public List<Student> findAll();
	
	public Student findById(Long id);
	
	public Student save(Student student);
	
	public void delete(Long id);
	
	public Student findStudentByID(Long id);

}
