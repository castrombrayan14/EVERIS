package com.everis.rest.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.everis.rest.models.entity.Parent;
import com.everis.rest.models.repository.IParentRepository;

@Service
public class ParentServiceImpl implements IParentService{

	@Autowired
	private IParentRepository parentRepository;
	
	@Override
	@Transactional(readOnly = true)
	public List<Parent> findAll() {

		return parentRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Parent findById(Long id) {

		return parentRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Parent save(Parent parent) {
	
		return parentRepository.save(parent);
	}

	@Override
	@Transactional
	public void delete(Long id) {
		
		parentRepository.deleteById(id);
		
	}

}
