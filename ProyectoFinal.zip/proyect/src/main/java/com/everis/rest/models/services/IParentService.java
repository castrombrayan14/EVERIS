package com.everis.rest.models.services;

import java.util.List;

import com.everis.rest.models.entity.Parent;



public interface IParentService {
	
public List<Parent> findAll();
	
	public Parent findById(Long id);
	
	public Parent save(Parent parent);
	
	public void delete(Long id);

}
