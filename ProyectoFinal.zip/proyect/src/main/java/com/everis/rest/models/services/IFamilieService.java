package com.everis.rest.models.services;

import java.util.List;

import com.everis.rest.models.entity.Familie;

public interface IFamilieService {

	public List<Familie> findAll();
	
	public void saveFamilie(Familie familie);
	
	public List<Familie> getFamiliesParent (Long id);
}
