package com.everis.rest.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.everis.rest.models.entity.Familie;
import com.everis.rest.models.entity.FamilyMembers;
import com.everis.rest.models.services.IFamilyMemberService;

@RestController
@RequestMapping("/api")
public class FamilyMemberRestController {

	@Autowired
	private IFamilyMemberService familyMemberService;
	
	@GetMapping("/listfamilyMember")
	public ResponseEntity<?> listFamilyMember(){
		
		List<FamilyMembers> listaFamilyMember = familyMemberService.findAll();
	    if(listaFamilyMember!=null) {
	    	if(listaFamilyMember.size()!=0) {
	    		return new ResponseEntity<>(listaFamilyMember, HttpStatus.OK);
	    	}else {
	    	    return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	    	}
	    } else {
	    	
	    	return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	    }
	
	}
	
	
	//se manda el id de la clase parent para buscar la lista
	@PostMapping("/crearfamilyMember")
	public ResponseEntity<?> saveFamilyMember(@RequestBody FamilyMembers familyMembers){
		
		familyMemberService.saveFamilyMember(familyMembers);
		return  new ResponseEntity<Void>(HttpStatus.CREATED); 
	}
	
    @PostMapping("/familyMember_familie")
	public ResponseEntity<?> listFamiliesofFamilyMember(@RequestBody Familie familie){
		
		List<FamilyMembers> listaFamilyMember= familyMemberService.getFamilyMemberFamilie(familie.getFamily_id());
		  if(listaFamilyMember!=null) {
		    	if(listaFamilyMember.size()!=0) {
		    		return new ResponseEntity<>(listaFamilyMember, HttpStatus.OK);
		    	}else {
		    	    return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		    	}
		    } else {
		    	
		    	return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		    }
	}
	
}
