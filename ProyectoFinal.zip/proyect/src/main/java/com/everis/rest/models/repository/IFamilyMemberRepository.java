package com.everis.rest.models.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.everis.rest.models.entity.FamilyMembers;


@Repository
public interface IFamilyMemberRepository extends JpaRepository<FamilyMembers, Long> {
	
	//Propiedad del crudrepository que busca el id segun como se declaro el atributo en la clase FamilyMembers
	public List<FamilyMembers> findByFamilyId(Long familieId);

}
