package com.everis.rest.models.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.everis.rest.models.entity.Student;

@Repository
public interface IStudentRepository extends JpaRepository<Student, Long>{

	@Query("select s from Student s where s.id=?1")
	public Student findByIdSQL(Long id);
}
