package com.everis.rest.models.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.everis.rest.models.entity.Familie;

@Repository
public interface IFamilieRepository extends JpaRepository<Familie, Long> {
	
	public List<Familie> findByParentId(Long id);

}
