package com.everis.rest.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.everis.rest.models.entity.Parent;
import com.everis.rest.models.services.IParentService;

@RestController
@RequestMapping("/api")
public class ParentRestController {
	
	@Autowired
	private	IParentService parentService;
	
    //para llamar en la url	
	@GetMapping("/listParents")
	public List<Parent> listParent() {
		
		return parentService.findAll();
	}

	@GetMapping("/parents/{id}")
	public Parent findParent(@PathVariable Long id) {
		
		return parentService.findById(id);
		
	}
	@PostMapping("/saveParents")
	@ResponseStatus(HttpStatus.CREATED)
	public Parent saveParents(@RequestBody Parent parent) {
		
		return parentService.save(parent);
	} 

	@PutMapping("/updateParents/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public Parent updateParent(@RequestBody Parent parent,@PathVariable Long id) {
		
		Parent parentCurrent =parentService.findById(id);
		
		parentCurrent.setGender(parent.getGender());
		parentCurrent.setFirst_name(parent.getFirst_name());
		parentCurrent.setMiddle_name(parent.getMiddle_name());
		parentCurrent.setLast_name(parent.getLast_name());
		parentCurrent.setOther_parents_details(parent.getOther_parents_details());
     	
		
		return 	parentService.save(parentCurrent);
		
	}
	
	@DeleteMapping("/parents/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteParent(@PathVariable Long id) {
		parentService.delete(id);
		
	}
	
}
